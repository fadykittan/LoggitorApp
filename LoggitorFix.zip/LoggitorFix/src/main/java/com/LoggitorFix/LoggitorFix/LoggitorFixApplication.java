package com.LoggitorFix.LoggitorFix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoggitorFixApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoggitorFixApplication.class, args);
	}

}

